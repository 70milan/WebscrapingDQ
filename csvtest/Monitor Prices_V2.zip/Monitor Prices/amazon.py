import datetime
import config
import csvhandler
import pricehandler as ph
import os
import mailhandler

date_stamp = None
time_stamp = None
price_list = {}

# Get price for all prdocuts
for item in config.product_urls:
    date_stamp = datetime.datetime.now().date()
    time_stamp = datetime.datetime.now().time()
    price = price_list[item] = ph.return_price(config.product_urls[item])
    file = os.path.join(config.csv_folder, item +".csv")
    row_to_write = [date_stamp, time_stamp, price]
    csvhandler.writetocsv(row_to_write, file)

# Send final mail
price_details = ""

for item in price_list:
    price_details += "\t" + item + " : " + str(price_list[item]) + "\n" 

mail_subject = "Price Updates"
mail_body = "Todays price updates:\n\n" + price_details

mailhandler.sendmail(mail_subject, mail_body)


