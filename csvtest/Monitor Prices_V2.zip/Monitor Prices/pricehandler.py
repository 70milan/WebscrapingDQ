import config
import requests
from bs4 import BeautifulSoup

def return_price(address:str)->float:
    response = requests.get(address, headers=config.header_values)
    response_text = response.text
        
    soup = BeautifulSoup(response_text,"lxml")
    
    regular_price_element = soup.find("span",{"id":"priceblock_ourprice"})
    deal_price_element = soup.find("span",{"id":"priceblock_dealprice"})
    
    if deal_price_element is not None:
        price_as_text = deal_price_element.text
    elif regular_price_element is not None:
        price_as_text  = regular_price_element.text
    else:
        price_as_text = -1 # Returning -1 is a programming convention to indicate an error
    
    price = strip_currency_symbol(price_as_text)
    
    return price

def strip_currency_symbol(price_as_text:str) -> float:
    try:
        price = float(price_as_text.strip("$").strip("₹ ").strip("AED").replace(",",""))
    except:
        price = -1
        # TODO: log original value sent
    
    return price
