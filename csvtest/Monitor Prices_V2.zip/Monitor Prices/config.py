product_urls = {
    "QC 35 US" : "https://www.amazon.com/Bose-QuietComfort-Wireless-Headphones-Cancelling/dp/B0756CYWWD/ref=sr_1_3?keywords=qc35&qid=1562133678&s=gateway&sr=8-3",
    "1000xm3 US" : "https://www.amazon.com/Sony-Noise-Cancelling-Headphones-WH1000XM3/dp/B07G4YL6BM/ref=sr_1_3?crid=1FROVTWCPDRF0&keywords=1000xm3&qid=1562312586&s=gateway&smid=ATVPDKIKX0DER&sprefix=1000xm%2Caps%2C361&sr=8-3",
    "QC 35 India" : "https://www.amazon.in/Bose-Quiet-Comfort-Wireless-Headphone/dp/B0756CYWWD/ref=sr_1_1_sspa?crid=2F6U2P7YVE3Y0&keywords=bose+qc35&qid=1562576018&s=gateway&sprefix=qc35+ear+cushion%2Caps%2C359&sr=8-1-spons&psc=1",
    "QC 35 UAE" : "https://www.amazon.ae/Bose-QuietComfort-Wireless-Cancelling-Headphones/dp/B0756CYWWD/ref=sr_1_2?keywords=qc35&qid=1562744818&s=gateway&smid=A2KKU8J8O8784X&sr=8-2"
}

header_values = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'Accept-Encoding':	'gzip, deflate',
    'Accept-Language':	'en-US,en;q=0.9,hi;q=0.8',
    'Connection':	'keep-alive',
    # 'Host':	'www.amazon.com',
    'Referer':	'https://www.google.com/',
    'Upgrade-Insecure-Requests':	'1',
    'User-Agent':	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
}


csv_folder =(r"c:\learnPython")
USER_NAME = "eupendrajunk@gmail.com"
USER_PASS = "lfniwawbkmzdmkev"

